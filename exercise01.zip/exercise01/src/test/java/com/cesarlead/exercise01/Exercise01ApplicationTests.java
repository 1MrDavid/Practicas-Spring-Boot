package com.cesarlead.exercise01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercise01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
