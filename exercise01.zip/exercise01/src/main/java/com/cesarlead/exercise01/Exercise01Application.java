package com.cesarlead.exercise01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercise01Application {

	public static void main(String[] args) {
		SpringApplication.run(Exercise01Application.class, args);
	}

}
