package com.cesarlead.DACourses;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaCoursesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaCoursesApplication.class, args);
	}

}
